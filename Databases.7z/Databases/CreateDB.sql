CREATE DATABASE 'Database\Schedule.gdb' USER 'SYSDBA' PASSWORD 'masterkey' DEFAULT CHARACTER SET WIN1251;
CONNECT 'Database\Schedule.gdb' USER 'SYSDBA' PASSWORD 'masterkey';

CREATE TABLE timeslots(id INTEGER NOT NULL PRIMARY KEY, name VARCHAR(256), number INTEGER NOT NULL);
CREATE TABLE weekdays(id INTEGER NOT NULL PRIMARY KEY, name VARCHAR(256), number INTEGER NOT NULL);
CREATE TABLE groups(id INTEGER NOT NULL PRIMARY KEY, name VARCHAR(256), ItemCount INTEGER NOT NULL);
CREATE TABLE rooms(id INTEGER NOT NULL PRIMARY KEY, name VARCHAR(256), ItemCapacity INTEGER NOT NULL);

CREATE TABLE subjects(id INTEGER NOT NULL PRIMARY KEY, name VARCHAR(256));
CREATE TABLE teachers(id INTEGER NOT NULL PRIMARY KEY, name VARCHAR(256));
CREATE TABLE group_subj_teacher(
								id INTEGER NOT NULL PRIMARY KEY,
								group_id INTEGER NOT NULL REFERENCES groups(id),
								subject_id INTEGER NOT NULL REFERENCES subjects(id),
								teacher_id INTEGER NOT NULL REFERENCES teachers(id)
								);

CREATE TABLE Schedule_items(
							id INTEGER NOT NULL PRIMARY KEY,
							time_slot_id INTEGER NOT NULL REFERENCES timeslots(id),
							weekday_id INTEGER NOT NULL REFERENCES weekdays(id),
							room_id INTEGER NOT NULL REFERENCES rooms(id),
							group_subj_teacher_ID INTEGER NOT NULL REFERENCES group_subj_teacher(id), 
							start_date DATE NOT NULL,
							end_date DATE NOT NULL,
							period INTEGER NOT NULL
						);
						
						
SELECT schedule_items.id, time_slot_id, weekday_id, room_id, timeslots.name AS time_slot_name, weekdays.name AS weekday_name, rooms.name AS room_name,
COUNT(DISTINCT group_subj_teacher_ID) AS subjects_count
FROM schedule_items
INNER JOIN timeslots ON time_slot_id = timeslots.id
INNER JOIN weekdays ON weekday_id = weekdays.id
INNER JOIN rooms ON room_id = rooms.id
GROUP BY time_slot_id, weekday_id, room_id, time_slot_name, weekday_name, room_name
HAVING COUNT(DISTINCT group_subj_teacher_ID) > 1�

CREATE GENERATOR ID_GEN;

SET GENERATOR ID_GEN TO 1000;


SET TERM !! ;

CREATE TRIGGER ID_INCREASE_SCHITEMS FOR SCHEDULE_ITEMS
 BEFORE INSERT
AS 
BEGIN 
    IF (INSERTING AND NEW.ID IS NULL) THEN 
        NEW.ID = GEN_ID (ID_GEN, 1) ;
END !!

CREATE TRIGGER ID_INCREASE_GRPS FOR GROUPS
 BEFORE INSERT
AS 
BEGIN 
    IF (INSERTING AND NEW.ID IS NULL) THEN 
        NEW.ID = GEN_ID (ID_GEN, 1) ;
END !!

CREATE TRIGGER ID_INCREASE_RMS FOR ROOMS
 BEFORE INSERT
AS 
BEGIN 
    IF (INSERTING AND NEW.ID IS NULL) THEN 
        NEW.ID = GEN_ID (ID_GEN, 1) ;
END !!

CREATE TRIGGER ID_INCREASE_GST FOR GROUP_SUBJ_TEACHER
 BEFORE INSERT
AS 
BEGIN 
    IF (INSERTING AND NEW.ID IS NULL) THEN 
        NEW.ID = GEN_ID (ID_GEN, 1) ;
END !!

CREATE TRIGGER ID_INCREASE_TCHRS FOR TEACHERS
 BEFORE INSERT
AS 
BEGIN 
    IF (INSERTING AND NEW.ID IS NULL) THEN 
        NEW.ID = GEN_ID (ID_GEN, 1) ;
END !!

CREATE TRIGGER ID_INCREASE_SUBJ FOR SUBJECTS
 BEFORE INSERT
AS 
BEGIN 
    IF (INSERTING AND NEW.ID IS NULL) THEN 
        NEW.ID = GEN_ID (ID_GEN, 1) ;
END !!

CREATE TRIGGER ID_INCREASE_WKDS FOR WEEKDAYS
 BEFORE INSERT
AS 
BEGIN 
    IF (INSERTING AND NEW.ID IS NULL) THEN 
        NEW.ID = GEN_ID (ID_GEN, 1) ;
END !!

CREATE TRIGGER ID_INCREASE_TSLTS FOR TIMESLOTS
 BEFORE INSERT
AS 
BEGIN 
    IF (INSERTING AND NEW.ID IS NULL) THEN 
        NEW.ID = GEN_ID (ID_GEN, 1) ;
END !!

SET TERM ; !!